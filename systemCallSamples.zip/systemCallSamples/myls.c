#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>

#define MAX_FILENAME 50

int main (int c, char *v[]) {
    int len;
    struct dirent *pDirent;
    DIR *pDir;

    if (c < 2) {
        printf ("Usage: myls <dirname>\n");
        return 1;
    }
    pDir = opendir (v[1]);
    if (pDir == NULL) {
        printf ("Cannot open directory '%s'\n", v[1]);
        return 1;
    }

    struct stat statbuf;

    while ((pDirent = readdir(pDir)) != NULL) {
	if (strcmp(pDirent->d_name, ".") == 0 || strcmp(pDirent->d_name, "..") == 0)
	  continue;
        printf ("[%s]:", pDirent->d_name);
	stat(pDirent->d_name, &statbuf);
	printf("%s ", ctime(&(statbuf.st_mtime)));
	printf("\n");
    }
    closedir (pDir);
    return 0;
}
